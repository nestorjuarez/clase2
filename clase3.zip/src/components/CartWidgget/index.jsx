import React from "react";
import {FiShoppingCart} from 'react-icons/fi';
const Cartwidgget = ()=>{
    return(
        <FiShoppingCart style={{padding:15}}/>
    );
}

export default Cartwidgget