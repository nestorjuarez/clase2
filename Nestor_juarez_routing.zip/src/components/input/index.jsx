import React from "react";
import './styles.css';

const Input = (props) => {
  return (
      <input type="" name="" value="" placeholder={props.valorPlaceholder} className="app-input"/>
  );
}


export default Input