import React from 'react'

export default function NotFound() {
  return (
    <div><h1>NotFound 404</h1></div>
  )
}
