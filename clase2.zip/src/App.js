import logo from './logo.svg';
import './App.css';
import NavBar from './components/NavBar';

function App() {
  let nombre="Nestor"
  return (
    <div className='container'>
      <div className="App" >
        <NavBar/>

    </div>
    </div>
    
  );
}

export default App;
